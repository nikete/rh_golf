"""Check a lower bound on the RH tournament's exact theorem-reuse score."""
import argparse
from array import array
import gzip
import hashlib
import json
from pathlib import Path
import sys

GRAPH_LOCK = "7af1330fda5dda55fd31f31a576c2af9f91043f061045e57ba98b5507b744714"
EXPORT = "61a8938ad5f5e57397c1c0e3b954916af546d9004ade01c3555744a681b05381"
SIGNATURES = "4152f958a5a3e700075bd16e798db08d3ae67a597269fa43586cfcc93dc749b2"
SCALE = 1024
HERE = Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def words(data, typecode="I"):
    result = array(typecode)
    result.frombytes(data)
    if sys.byteorder != "little":
        result.byteswap()
    return result


class Archive:
    def __init__(self, repo, graph):
        lock = (repo / "judge/archive_graph.lock.json").read_bytes()
        if digest(lock) != GRAPH_LOCK:
            raise ValueError("Unexpected graph lock")
        lock = json.loads(lock)
        if lock["export_sha256"] != EXPORT:
            raise ValueError("Unexpected original export")
        for file, pin in lock["files"].items():
            data = (graph / file).read_bytes()
            if digest(data) != pin["sha256"] or len(data) != pin["bytes"]:
                raise ValueError(f"Unauthenticated graph member {file}")
            if file == "groups.bin":
                self.nodes = words(data)
            elif file == "dependencies.bin":
                self.edges = words(data)
            elif file == "manifest.json":
                manifest = json.loads(data)
                self.root = manifest["root"]
                self.baseline = manifest["baseline"]
        self.count = len(self.nodes) // 4  # Includes reserved group zero.
        self.signature = array("i", [-1]) * self.count
        with gzip.open(repo / "judge/reuse/signatures.jsonl.gz", "rb") as f:
            data = f.read()
        if digest(data) != SIGNATURES:
            raise ValueError("Unexpected exact theorem signature index")
        header, *rows = data.splitlines()
        if json.loads(header)["export"] != EXPORT:
            raise ValueError("Unexpected signature origin")
        self.classes = []
        for number, row in enumerate(rows):
            _, _, size, type_deps, members, library = json.loads(row)
            self.classes.append((size + 1, type_deps, members, bool(library)))
            for group in members:
                if self.signature[group] >= 0:
                    raise ValueError("Repeated signature member")
                self.signature[group] = number

    def deps(self, group):
        p = 4 * group
        off = self.nodes[p + 1]
        return self.edges[off:off + self.nodes[p + 2]]

    def weight(self, group):
        return self.nodes[4 * group]


class Obligations:
    """An implication g -> d means every proof of g contains d in its closure.

    An extra node for each signature represents 'some group of this class is live'.
    """
    def __init__(self, archive):
        self.archive = archive
        self.n = archive.count
        self.anchors = []
        self.required = []
        for c, (_, _, members, library) in enumerate(archive.classes):
            anchors = [] if library else [g for g in members
                       if all(archive.signature[d] != c for d in archive.deps(g))]
            self.anchors.append(anchors)
            self.required.append(self.direct(c))
        self.remove_circular_anchors()
        self.enrich()

    def direct(self, c):
        _, types, _, library = self.archive.classes[c]
        requirements = set(types)
        if not library:
            choices = self.anchors[c]
            if not choices:
                raise ValueError("A required signature class lost all potential original proofs")
            shared = set(self.archive.deps(choices[0]))
            for group in choices[1:]:
                shared.intersection_update(self.archive.deps(group))
            requirements.update(shared)
            if len(choices) == 1:
                requirements.add(choices[0])
        return sorted(requirements)

    def deps(self, node):
        if node >= self.n:
            return self.required[node - self.n]
        c = self.archive.signature[node]
        if c >= 0:
            return (self.n + c,)
        return self.archive.deps(node)

    def remove_circular_anchors(self):
        # In an acyclic proof, the earliest used member of a no-library signature
        # keeps its original body. No dependency of that body can require this class.
        for _ in range(10):
            dropped = 0
            for c, anchors in enumerate(self.anchors):
                if len(anchors) <= 1:
                    continue
                earliest = min(self.archive.classes[c][2])
                remaining = []
                for g in anchors:
                    pending = list(self.archive.deps(g))
                    visited = set()
                    circular = False
                    while pending and len(visited) < 10000:
                        d = pending.pop()
                        if d < earliest or d in visited:
                            continue
                        if d == self.n + c or (d < self.n and self.archive.signature[d] == c):
                            circular = True
                            break
                        visited.add(d)
                        pending.extend(self.deps(d))
                    if not circular:
                        remaining.append(g)
                if len(remaining) != len(anchors):
                    self.anchors[c] = remaining
                    self.required[c] = self.direct(c)
                    dropped += len(anchors) - len(remaining)
            if not dropped:
                return

    def mandatory_closure(self):
        active = bytearray(self.n + len(self.anchors))
        pending = [self.archive.root]
        while pending:
            g = pending.pop()
            if not active[g]:
                active[g] = 1
                pending.extend(self.deps(g))
        return active

    def conditional(self, group):
        # Every discovered vertex has a witnessed implication path. The cap can
        # omit useful implications and makes the result a conservative lower bound.
        found = set()
        pending = [group, *self.archive.deps(group)]
        while pending and len(found) < 20000:
            d = pending.pop()
            if not self.active[d] and d not in found:
                found.add(d)
                pending.extend(self.deps(d))
        return found

    def enrich(self):
        for _ in range(12):
            self.active = self.mandatory_closure()
            changes = 0
            for c, anchors in enumerate(self.anchors):
                if len(anchors) <= 1:
                    continue
                shared = self.conditional(anchors[0])
                for g in anchors[1:]:
                    if not shared:
                        break
                    shared.intersection_update(self.conditional(g))
                added = shared.difference(self.required[c], (self.n + c,))
                if added:
                    self.required[c] = sorted(set(self.required[c]).union(added))
                    changes += len(added)
            if not changes:
                break
        self.active = self.mandatory_closure()


class Relaxation:
    def __init__(self, obligations):
        self.ob = obligations
        ar = obligations.archive
        self.constant = 0
        self.costs = []
        self.active = array("i", [-1]) * len(obligations.active)
        self.choice = array("i", [-1]) * ar.count
        for g in range(1, len(obligations.active)):
            value = 0
            if g < ar.count:
                c = ar.signature[g]
                value = ar.weight(g) if c < 0 else min(ar.weight(g), ar.classes[c][0])
            if obligations.active[g]:
                self.constant += value
            else:
                self.active[g] = self.variable(value)
        for c, anchors in enumerate(obligations.anchors):
            fixed = obligations.active[ar.count + c] and len(anchors) == 1
            for g in anchors:
                extra = max(0, ar.weight(g) - ar.classes[c][0])
                if fixed:
                    if not obligations.active[g] or not all(obligations.active[d] for d in ar.deps(g)):
                        raise ValueError("Unpropagated required original proof")
                    self.constant += extra
                else:
                    self.choice[g] = self.variable(extra)

    def variable(self, cost):
        self.costs.append(cost)
        return len(self.costs) - 1

    def rows(self):
        """Yield integer constraints A*x <= b as (positive indices, negative indices, b)."""
        ob = self.ob
        ar = ob.archive
        for g in range(1, len(ob.active)):
            ix = self.active[g]
            if ix < 0:
                continue
            for d in ob.deps(g):
                if d != g and self.active[d] >= 0:
                    yield (ix,), (self.active[d],), 0
        for c, anchors in enumerate(ob.anchors):
            if not anchors:
                continue
            use = self.active[ar.count + c]
            if use < 0 and len(anchors) == 1:
                continue
            keys = [self.choice[g] for g in anchors]
            for g, key in zip(anchors, keys):
                for d in [g, *ar.deps(g)]:
                    if self.active[d] >= 0:
                        yield (key,), (self.active[d],), 0
            # Exactly one designated earliest original for each active no-library class.
            if use < 0:
                yield (), keys, -1
                yield keys, (), 1
            else:
                yield (use,), keys, 0
                yield keys, (use,), 0
            if len(anchors) <= 1:
                continue
            requirements = {}
            for g in anchors:
                for d in ob.conditional(g):
                    requirements.setdefault(d, []).append(self.choice[g])
            for d in sorted(requirements):
                subset = requirements[d]
                if len(subset) > 1 and d != ar.count + c:
                    yield subset, (self.active[d],), 0


def solve(model, file):
    import numpy as np
    from scipy.sparse import csr_matrix
    from scipy.optimize import linprog
    indices, pointers = array("i"), array("i", [0])
    values, rhs = array("b"), array("i")
    for plus, minus, bound in model.rows():
        indices.extend(plus); indices.extend(minus)
        values.extend([1] * len(plus)); values.extend([-1] * len(minus))
        pointers.append(len(indices)); rhs.append(bound)
    matrix = csr_matrix((np.asarray(values), np.asarray(indices), np.asarray(pointers)),
                        shape=(len(rhs), len(model.costs)))
    result = linprog(model.costs, A_ub=matrix, b_ub=rhs, bounds=(0, 1), method="highs")
    if not result.success:
        raise ValueError(result.message)
    dual = array("q", (max(0, round(-d * SCALE)) for d in result.ineqlin.marginals))
    if sys.byteorder != "little":
        dual.byteswap()
    file.write_bytes(gzip.compress(dual.tobytes(), mtime=0))


def verify(model, file):
    with gzip.open(file, "rb") as f:
        multipliers = words(f.read(), "q")
    # For any nonnegative y and feasible x in the unit box,
    # c'x >= -b'y + sum_j min(0, c[j] + (A'y)[j]).
    # Python integers make the entire dual calculation exact.
    residual = [cost * SCALE for cost in model.costs]
    constant = model.constant * SCALE
    count = 0
    for plus, minus, bound in model.rows():
        if count >= len(multipliers):
            raise ValueError("Truncated dual certificate")
        y = multipliers[count]
        count += 1
        if y < 0:
            raise ValueError("Negative constraint multiplier")
        if y:
            constant -= y * bound
            for k in plus:
                residual[k] += y
            for k in minus:
                residual[k] -= y
    if count != len(multipliers):
        raise ValueError("Unexpected trailing constraint multipliers")
    lower = (constant + sum(min(0, c) for c in residual) + SCALE - 1) // SCALE
    ar = model.ob.archive
    return {"baseline_nodes": ar.baseline, "exact_reuse_lower_bound": lower,
            "maximum_total_saving": ar.baseline - lower, "constraints": count,
            "mandatory_groups": sum(model.ob.active[:ar.count]),
            "mandatory_signatures": sum(model.ob.active[ar.count:])}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo", required=True, type=Path)
    p.add_argument("--graph", required=True, type=Path)
    p.add_argument("--certificate", type=Path, default=HERE / "multipliers.gz")
    p.add_argument("--solve", action="store_true", help="Generate new dual multipliers with SciPy/HiGHS before checking")
    args = p.parse_args()
    model = Relaxation(Obligations(Archive(args.repo, args.graph)))
    if args.solve:
        solve(model, args.certificate)
    print(json.dumps(verify(model, args.certificate), indent=2))
